import React, { useState, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './components/ui/Card';
import { Button } from './components/ui/Button';
import { Input } from './components/ui/Input';
import { Textarea } from './components/ui/Textarea';

// Simuler des données pour le développement frontend
const fakeLaws = [
  { id: 1, description: "Réduction des émissions de CO2", ipfsHash: "QmX...", status: "active", approvalCount: 10, rejectionCount: 5 },
  { id: 2, description: "Protection des données personnelles", ipfsHash: "QmY...", status: "finalized", approved: true },
  { id: 3, description: "Régulation des cryptomonnaies", ipfsHash: "QmZ...", status: "active", approvalCount: 8, rejectionCount: 12 },
];

const ProposeLawForm = React.memo(({ newLaw, onSubmit, onDescriptionChange, onIpfsChange }) => (
  <Card className="mb-6">
    <CardHeader>
      <CardTitle>Proposer une nouvelle loi</CardTitle>
    </CardHeader>
    <CardContent>
      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <Textarea
            placeholder="Description de la loi"
            value={newLaw.description}
            onChange={onDescriptionChange}
            className="w-full"
          />
        </div>
        <div>
          <Input
            placeholder="Hash IPFS"
            value={newLaw.ipfsHash}
            onChange={onIpfsChange}
            className="w-full"
          />
        </div>
        <Button type="submit">Soumettre la proposition</Button>
      </form>
    </CardContent>
  </Card>
));

const ActiveLawsList = React.memo(({ laws, onVote }) => (
  <Card className="mb-6">
    <CardHeader>
      <CardTitle>Lois actives</CardTitle>
    </CardHeader>
    <CardContent>
      {laws.filter(law => law.status === 'active').map(law => (
        <div key={law.id} className="mb-4 p-4 border rounded">
          <p className="mb-2">{law.description}</p>
          <p className="text-sm text-gray-500 mb-2">IPFS: {law.ipfsHash}</p>
          <div className="flex gap-2">
            <Button 
              onClick={() => onVote(law.id, 'approve')}
              className="bg-green-500 hover:bg-green-600"
            >
              Approuver ({law.approvalCount})
            </Button>
            <Button 
              onClick={() => onVote(law.id, 'reject')}
              className="bg-red-500 hover:bg-red-600"
            >
              Rejeter ({law.rejectionCount})
            </Button>
          </div>
        </div>
      ))}
    </CardContent>
  </Card>
));

const FinalizedLawsList = React.memo(({ laws }) => (
  <Card>
    <CardHeader>
      <CardTitle>Résultats des votes</CardTitle>
    </CardHeader>
    <CardContent>
      {laws.filter(law => law.status === 'finalized').map(law => (
        <div key={law.id} className="mb-4 p-4 border rounded">
          <p className="mb-2">{law.description}</p>
          <p className="text-sm text-gray-500 mb-2">IPFS: {law.ipfsHash}</p>
          <p className={`font-bold ${law.approved ? 'text-green-500' : 'text-red-500'}`}>
            {law.approved ? 'Approuvée' : 'Rejetée'}
          </p>
        </div>
      ))}
    </CardContent>
  </Card>
));

const VotingApp = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [laws, setLaws] = useState(fakeLaws);
  const [newLaw, setNewLaw] = useState({ description: '', ipfsHash: '' });

  const handleSubmit = useCallback((e) => {
    e.preventDefault();
    const law = {
      id: laws.length + 1,
      ...newLaw,
      status: 'active',
      approvalCount: 0,
      rejectionCount: 0
    };
    setLaws(prev => [...prev, law]);
    setNewLaw({ description: '', ipfsHash: '' });
  }, [newLaw]);

  const handleDescriptionChange = useCallback((e) => {
    setNewLaw(prev => ({ ...prev, description: e.target.value }));
  }, []);

  const handleIpfsChange = useCallback((e) => {
    setNewLaw(prev => ({ ...prev, ipfsHash: e.target.value }));
  }, []);

  const handleVote = useCallback((lawId, vote) => {
    setLaws(prev => prev.map(law => {
      if (law.id === lawId) {
        if (vote === 'approve') {
          return { ...law, approvalCount: law.approvalCount + 1 };
        } else {
          return { ...law, rejectionCount: law.rejectionCount + 1 };
        }
      }
      return law;
    }));
  }, []);

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="text-right mb-4">
        {!isConnected ? (
          <Button onClick={() => setIsConnected(true)}>
            Connecter avec MetaMask
          </Button>
        ) : (
          <span className="text-green-500">Connecté ✓</span>
        )}
      </div>
      
      <ProposeLawForm
        newLaw={newLaw}
        onSubmit={handleSubmit}
        onDescriptionChange={handleDescriptionChange}
        onIpfsChange={handleIpfsChange}
      />
      <ActiveLawsList laws={laws} onVote={handleVote} />
      <FinalizedLawsList laws={laws} />
    </div>
  );
};

export default VotingApp;